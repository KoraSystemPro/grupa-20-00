﻿using System;

namespace Pokemoni
{
    internal class Magija
    {
        // Polja
        private String ime;
        private int dmg;
        private String tip;

        // Kontruktor
        public Magija(String ime, int dmg, String tip)
        {
            this.ime = ime;
            this.dmg = dmg;
            this.tip = tip;
        }

        public String getMagija()
        {
            return this.ime;
        }

        public override String ToString()
        {
            // (vatra) fireball
            return "("+ tip + ") " + ime;
        }
        public int getDmg()
        {
            return dmg;
        }
    }
}