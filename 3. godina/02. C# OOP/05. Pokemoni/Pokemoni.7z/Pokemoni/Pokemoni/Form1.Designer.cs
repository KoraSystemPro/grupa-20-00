﻿namespace Pokemoni
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RB_pokemon1 = new System.Windows.Forms.RadioButton();
            this.RB_pokemon2 = new System.Windows.Forms.RadioButton();
            this.RB_magija1 = new System.Windows.Forms.RadioButton();
            this.RB_magija2 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BTN_igraj = new System.Windows.Forms.Button();
            this.BTN_reset = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // RB_pokemon1
            // 
            this.RB_pokemon1.AutoSize = true;
            this.RB_pokemon1.Checked = true;
            this.RB_pokemon1.Location = new System.Drawing.Point(6, 27);
            this.RB_pokemon1.Name = "RB_pokemon1";
            this.RB_pokemon1.Size = new System.Drawing.Size(126, 24);
            this.RB_pokemon1.TabIndex = 1;
            this.RB_pokemon1.TabStop = true;
            this.RB_pokemon1.Text = "radioButton1";
            this.RB_pokemon1.UseVisualStyleBackColor = true;
            this.RB_pokemon1.CheckedChanged += new System.EventHandler(this.RB_pokemon1_CheckedChanged);
            // 
            // RB_pokemon2
            // 
            this.RB_pokemon2.AutoSize = true;
            this.RB_pokemon2.Location = new System.Drawing.Point(6, 58);
            this.RB_pokemon2.Name = "RB_pokemon2";
            this.RB_pokemon2.Size = new System.Drawing.Size(126, 24);
            this.RB_pokemon2.TabIndex = 2;
            this.RB_pokemon2.Text = "radioButton2";
            this.RB_pokemon2.UseVisualStyleBackColor = true;
            // 
            // RB_magija1
            // 
            this.RB_magija1.AutoSize = true;
            this.RB_magija1.Checked = true;
            this.RB_magija1.Location = new System.Drawing.Point(6, 25);
            this.RB_magija1.Name = "RB_magija1";
            this.RB_magija1.Size = new System.Drawing.Size(126, 24);
            this.RB_magija1.TabIndex = 3;
            this.RB_magija1.TabStop = true;
            this.RB_magija1.Text = "radioButton3";
            this.RB_magija1.UseVisualStyleBackColor = true;
            // 
            // RB_magija2
            // 
            this.RB_magija2.AutoSize = true;
            this.RB_magija2.Location = new System.Drawing.Point(6, 56);
            this.RB_magija2.Name = "RB_magija2";
            this.RB_magija2.Size = new System.Drawing.Size(126, 24);
            this.RB_magija2.TabIndex = 4;
            this.RB_magija2.TabStop = true;
            this.RB_magija2.Text = "radioButton4";
            this.RB_magija2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RB_pokemon2);
            this.groupBox1.Controls.Add(this.RB_pokemon1);
            this.groupBox1.Location = new System.Drawing.Point(618, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(277, 88);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pokemini";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RB_magija1);
            this.groupBox2.Controls.Add(this.RB_magija2);
            this.groupBox2.Location = new System.Drawing.Point(618, 130);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(277, 86);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Magije";
            // 
            // BTN_igraj
            // 
            this.BTN_igraj.Location = new System.Drawing.Point(618, 403);
            this.BTN_igraj.Name = "BTN_igraj";
            this.BTN_igraj.Size = new System.Drawing.Size(105, 43);
            this.BTN_igraj.TabIndex = 7;
            this.BTN_igraj.Text = "Igraj";
            this.BTN_igraj.UseVisualStyleBackColor = true;
            this.BTN_igraj.Click += new System.EventHandler(this.BTN_igraj_Click);
            // 
            // BTN_reset
            // 
            this.BTN_reset.Location = new System.Drawing.Point(743, 403);
            this.BTN_reset.Name = "BTN_reset";
            this.BTN_reset.Size = new System.Drawing.Size(75, 43);
            this.BTN_reset.TabIndex = 8;
            this.BTN_reset.Text = "Reset";
            this.BTN_reset.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(593, 434);
            this.richTextBox1.TabIndex = 9;
            this.richTextBox1.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(907, 458);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.BTN_reset);
            this.Controls.Add(this.BTN_igraj);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RadioButton RB_pokemon1;
        private System.Windows.Forms.RadioButton RB_pokemon2;
        private System.Windows.Forms.RadioButton RB_magija1;
        private System.Windows.Forms.RadioButton RB_magija2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BTN_igraj;
        private System.Windows.Forms.Button BTN_reset;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

