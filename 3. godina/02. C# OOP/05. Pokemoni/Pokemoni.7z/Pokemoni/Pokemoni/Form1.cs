﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Pokemoni
{
    public partial class Form1 : Form
    {
        Trener igrac;
        Trener kompjuter;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // kljuc : vrednost
            // Pravimo recnik koji sadrzi sve magije
            Dictionary<String, Magija> magije = new Dictionary<String, Magija>();
            magije.Add("fireblast", new Magija("Fireblast", 3, "fire"));
            magije.Add("burning_tail", new Magija("Burning Tail", 2, "fire"));
            magije.Add("thunder_shock", new Magija("Thunder Shock", 4, "electric"));
            magije.Add("quick_attack", new Magija("Quick attack", 3, "physical"));
            magije.Add("psycho_blast", new Magija("Psycho blast", 5, "psychic"));
            magije.Add("focus_blast", new Magija("Focus blast", 3, "physical"));
            magije.Add("amaterasu", new Magija("Amaterasu", 4, "genkaj"));
            magije.Add("rasengan", new Magija("Rasengan", 3, "juitsu"));

            // Inicijalizujemo igru
            Pokemon charizard = new Pokemon("Charizard", 150, 20, magije["fireblast"], magije["burning_tail"]);
            Pokemon pikachu = new Pokemon("Pikachu", 100, 17, magije["thunder_shock"], magije["quick_attack"]);
            Pokemon mew = new Pokemon("Mew", 200, 23, magije["psycho_blast"], magije["focus_blast"]);
            Pokemon music = new Pokemon("Music", 130, 15, magije["amaterasu"], magije["rasengan"]);
            igrac = new Trener("Ana", charizard, pikachu);
            kompjuter = new Trener("Petar", mew, music);

            // Azuriramo formu
            RB_pokemon1.Text = igrac.getPokemon1().ispisiPokemona();
            RB_pokemon2.Text = igrac.getPokemon2().ispisiPokemona();

            RB_magija1.Text = igrac.getPokemon1().getMagija1().ToString();
            RB_magija2.Text = igrac.getPokemon1().getMagija2().ToString();

            richTextBox1.Text += igrac.ToString();
            richTextBox1.Text += kompjuter.ToString();

        }

        private void RB_pokemon1_CheckedChanged(object sender, EventArgs e)
        {
            if (RB_pokemon1.Checked)
            {
                RB_magija1.Text = igrac.getPokemon1().getMagija1().ToString();
                RB_magija2.Text = igrac.getPokemon1().getMagija2().ToString();
            }
            else
            {
                RB_magija1.Text = igrac.getPokemon2().getMagija1().ToString();
                RB_magija2.Text = igrac.getPokemon2().getMagija2().ToString();
            }
        }

        private void BTN_igraj_Click(object sender, EventArgs e)
        {
            

            // Dohvatamo izabranog pokemona
            Pokemon selektovanPokemon;
            if (RB_pokemon1.Checked)
                selektovanPokemon = igrac.getPokemon1();
            else
                selektovanPokemon = igrac.getPokemon2();
            
            // Dohvatamo izabranu magiju
            Magija selektovanaMagija;
            if (RB_magija1.Checked)
                selektovanaMagija = selektovanPokemon.getMagija1();
            else
                selektovanaMagija = selektovanPokemon.getMagija2();


            // Gledamo koga napadamo
            Pokemon neprijateljPokemon = kompjuter.getActivePokemon();
            if (neprijateljPokemon == null) // Ako je mrtav ne radimo nista
                return;

            // Igrac napada
            Pokemon.Borba(selektovanPokemon, neprijateljPokemon, selektovanaMagija, richTextBox1);
            richTextBox1.Text += igrac.ToString();
            richTextBox1.Text += kompjuter.ToString();

            // --- Kompjuter igra ----

            // Bira magiju
            Magija neprijateljMagija;
            Random generator = new Random();
            if (generator.Next(11) > 5)
                neprijateljMagija = neprijateljPokemon.getMagija1();
            else
                neprijateljMagija = neprijateljPokemon.getMagija2();

            richTextBox1.Text += "\nNeprijatelj bira potez....\n";
            // Thread.Sleep(2000);
            Pokemon.Borba(neprijateljPokemon, selektovanPokemon, neprijateljMagija, richTextBox1);
            
            // Proveravamo da li je pokemon ziv
            if (igrac.getPokemon1().Alive() == false)
            {
                RB_pokemon1.Enabled = false;
                RB_pokemon2.Checked = true;
            }
            if (igrac.getPokemon2().Alive() == false)
            {
                RB_pokemon2.Enabled = false;
                RB_pokemon1.Checked = true;
            }
            if(igrac.getPokemon1().Alive() == false && igrac.getPokemon2().Alive() == false)
            {
                richTextBox1.Text += "\n ---- Izgubio si ----";
                BTN_igraj.Enabled = false;
            }



        }
    }
}
