﻿using System;

namespace Pokemoni
{
    internal class Trener
    {
        private String ime;
        private Pokemon pok1;
        private Pokemon pok2;

        public Trener(String ime, Pokemon pokemon1, Pokemon pokemon2)
        {
            this.ime = ime;
            this.pok1 = pokemon1;
            this.pok2 = pokemon2;
        }
        public String getIme()
        {
            return ime;
        }
        public Pokemon getPokemon1()
        {
            return pok1;
        }
        public Pokemon getPokemon2()
        {
            return pok2;
        }
        public Pokemon getActivePokemon()
        {
            if (pok1.Alive())
                return pok1;
            else if (pok2.Alive())
                return pok2;
            else
                return null;
        }

        public void setPokemon1(Pokemon novi_pokemon)
        {
            pok1 = novi_pokemon;
        }
        public void setPokemon2(Pokemon novi_pokemon)
        {
            pok2 = novi_pokemon;
        }
        public void setPokemon(Pokemon novi1, Pokemon novi2)
        {
            pok1 = novi1;
            pok2 = novi2;
        }

        public override string ToString()
        {
            // Trener Pera
            // Pokemon1
            // Pokemon2
            // ------------
            return "Trener " + this.getIme() + "\n" +
                this.getPokemon1().ToString() + this.getPokemon2().ToString() + "------------------------------";
            // return "Trener " + ime + "\n" + pok1.ToString() + pok2.ToString();
        }
    }
}