﻿using System;
using System.Windows.Forms;

namespace Pokemoni
{
    internal class Pokemon
    {
        // 1. Atributi
        private String ime;
        private int zivot;
        private int nivo;
        private Magija magija1;
        private Magija magija2;

        // 2. Konstruktor
        public Pokemon(String ime, int zivot, int nivo, Magija m1, Magija m2)
        {
            this.ime = ime;
            this.zivot = zivot;
            this.nivo = nivo;
            this.magija1 = m1;
            this.magija2 = m2;
        }
        

        // 3. Metode
        
        public override String ToString()
        {
            // (lvl 13) Pikachu 123hp - (tip) Quick atack, Thunder Strike
            return "(lvl " + nivo + ") " + ime 
                + " " + zivot + "hp - " 
                + magija1.ToString() + ", " + magija2.ToString() + "\n";
        }

        public bool Alive()
        {
            if (this.zivot > 0)
                return true;
            return false;
        }

        public String ispisiPokemona()
        {
            return "(lvl " + nivo + ") " + ime;
        }

        public Magija getMagija1()
        {
            return magija1;
        }

        public Magija getMagija2()
        {
            return magija2;
        }
        private void napadni(Pokemon p2, Magija m)
        {
            p2.zivot -= m.getDmg()*(this.nivo/2);
            if (p2.zivot < 0)
                p2.zivot = 0;
        }

        public static void Borba(Pokemon napadac, Pokemon odbrana, Magija magija)
        {
            napadac.napadni(odbrana, magija);

        }
        public static void Borba(Pokemon napadac, Pokemon odbrana, Magija magija, RichTextBox rtb)
        {
            napadac.napadni(odbrana, magija);
            rtb.Text +=  "\n\n" + napadac.ime + " je iskoristio " + magija.getMagija() + " i napravio je " + magija.getDmg() * (napadac.nivo / 2) + "dmg " + odbrana.ime + "\n\n";

        }


    }


}