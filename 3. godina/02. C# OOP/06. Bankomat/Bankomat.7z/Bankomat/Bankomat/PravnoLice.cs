﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bankomat
{
    class PravnoLice : Klijent
    {
        String PIO;
        public PravnoLice(String PIO, String ime, Racun r) : base(ime, r)
        {
            this.PIO = PIO;
        }

        public override void transfer(Klijent primalac, float iznos, RichTextBox rtb)
        {
            if(primalac.Racun.valuta == this.Racun.valuta)
            {
                if (primalac is PrivatnoLice)
                {
                    primalac.Racun.uplata(iznos);
                    this.Racun.isplata(iznos * (float)1.08);
                    rtb.Text += this.ispisTransakcije(this, primalac, iznos);
                }
                if (primalac is PravnoLice)
                {
                    rtb.Text += this.ispisTransakcije(this, primalac, iznos);
                    primalac.Racun.uplata(iznos);
                    this.Racun.isplata(iznos * (float)1.12);
                }
            } else
            {
                rtb.Text += "Transfer nemoguć! Računi su u različitim valutama!\n";
            }
            
        }
    }
}
