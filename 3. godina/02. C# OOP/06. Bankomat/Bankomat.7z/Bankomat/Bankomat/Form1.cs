﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bankomat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void RBUplata_CheckedChanged(object sender, EventArgs e)
        {
            LStrelica.Visible = true;
            LIznos.Visible = true;
            TBIznos.Visible = true;
            LRacun.Visible = false;
            TBRacunUplate.Visible = false;
        }

        private void RBIsplata_CheckedChanged(object sender, EventArgs e)
        {
            LStrelica.Visible = true;
            LIznos.Visible = true;
            TBIznos.Visible = true;
            LRacun.Visible = true;
            TBRacunUplate.Visible = true;
        }

        private void RBUpit_CheckedChanged(object sender, EventArgs e)
        {
            LStrelica.Visible = false;
            LIznos.Visible = false;
            TBIznos.Visible = false;
            LRacun.Visible = false;
            TBRacunUplate.Visible = false;
        }

        private void RBIstorija_CheckedChanged(object sender, EventArgs e)
        {
            LStrelica.Visible = false;
            LIznos.Visible = false;
            TBIznos.Visible = false;
            LRacun.Visible = false;
            TBRacunUplate.Visible = false;
        }

        private void BTNOcisti_Click(object sender, EventArgs e)
        {
            RTBlog.Clear();
        }

        private void BTNIzvrsi_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PrivatnoLice luka = new PrivatnoLice("20052002710234", "Luka", new Racun(10, Valuta.EUR));
            PrivatnoLice matija = new PrivatnoLice("05052001710543", "Matija", new Racun(11, Valuta.EUR));
            luka.Racun.uplata(5000);
        }
    }
}
