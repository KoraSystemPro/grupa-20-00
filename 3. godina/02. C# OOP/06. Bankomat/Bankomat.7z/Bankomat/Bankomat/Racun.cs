﻿namespace Bankomat
{
    internal class Racun
    {
        uint broj;
        public Valuta valuta;
        float iznos;

        public Racun(uint broj, Valuta v)
        {
            this.broj = broj;
            valuta = v;
        }

        public override string ToString()
        {
            return "Broj racuna: " + broj + " : " + iznos + valuta.ToString();
        }

        public void uplata(float iznos)
        {
            this.iznos += iznos;
        }

        public void isplata(float iznost)
        {
            this.iznos -= iznos;
        }
    }
}