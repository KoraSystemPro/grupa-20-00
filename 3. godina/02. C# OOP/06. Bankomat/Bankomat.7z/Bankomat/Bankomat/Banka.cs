﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankomat
{
    class Banka
    {
        String ime;
        private int brojKlijenata;
        List<Klijent> klijenti;

        public Banka(String ime)
        {
            this.ime = ime;
            brojKlijenata = 0;
            klijenti = new List<Klijent>();
        }

        public void ubaciKlijenta(Klijent k)
        {
            klijenti.Add(k);
            brojKlijenata++;
        }
    }
}
