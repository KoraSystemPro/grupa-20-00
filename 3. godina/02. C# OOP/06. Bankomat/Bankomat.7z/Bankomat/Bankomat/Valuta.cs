﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankomat
{
    enum Valuta
    {
        USD, EUR, RSD, YEN, CHF, RUB, GBP, HRK, MKD
    }

}
