﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankomat
{
    class PrivatnoLice : Klijent
    {
        String JMBG;
        public PrivatnoLice(String JMBG, String ime, Racun r) : base(ime, r)
        {  
            this.JMBG = JMBG;
        }


        public override void transfer(Klijent primalac, float iznos, System.Windows.Forms.RichTextBox rtb)
        {
            if (primalac.Racun.valuta == this.Racun.valuta)
            {
                if (primalac is PrivatnoLice)
                {
                    primalac.Racun.uplata(iznos);
                    this.Racun.isplata(iznos * (float)1.02);
                    rtb.Text += this.ispisTransakcije(this, primalac, iznos);
                }
                if (primalac is PravnoLice)
                {
                    rtb.Text += this.ispisTransakcije(this, primalac, iznos);
                    primalac.Racun.uplata(iznos);
                    this.Racun.isplata(iznos);
                }
            } else
            {
                rtb.Text += "Transfer nemoguć! Računi su u različitim valutama!\n";
            }
        }
    }
}
