﻿using System;

namespace Bankomat
{
    public abstract class Klijent
    {
        String ime;
        Racun racun;

        public Klijent(String ime, Racun racun)
        {
            this.ime = ime;
            this.Racun = racun;
        }


        public abstract void transfer(Klijent primalac, float iznos, System.Windows.Forms.RichTextBox rtb);
 
        public String upitStanja()
        {
            return "Trenutno stanje za " + ime + " " + ":\n" + Racun.ToString();
        }

        protected String ispisTransakcije(Klijent k1, Klijent k2, float iznos)
        {
            return "Sa racuna " + k1.ime + " isplaceno je " + iznos + " , na racun " + k2.ime + "\n";
        }

    }
}