﻿namespace Bankomat
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RTBlog = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RBTransfer = new System.Windows.Forms.RadioButton();
            this.RBUpit = new System.Windows.Forms.RadioButton();
            this.RBIsplata = new System.Windows.Forms.RadioButton();
            this.RBUplata = new System.Windows.Forms.RadioButton();
            this.TBRacun = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LStrelica = new System.Windows.Forms.Label();
            this.TBIznos = new System.Windows.Forms.TextBox();
            this.TBRacunUplate = new System.Windows.Forms.TextBox();
            this.LIznos = new System.Windows.Forms.Label();
            this.LRacun = new System.Windows.Forms.Label();
            this.BTNIzvrsi = new System.Windows.Forms.Button();
            this.BTNOcisti = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // RTBlog
            // 
            this.RTBlog.Location = new System.Drawing.Point(12, 178);
            this.RTBlog.Name = "RTBlog";
            this.RTBlog.Size = new System.Drawing.Size(409, 228);
            this.RTBlog.TabIndex = 0;
            this.RTBlog.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RBTransfer);
            this.groupBox1.Controls.Add(this.RBUpit);
            this.groupBox1.Controls.Add(this.RBIsplata);
            this.groupBox1.Controls.Add(this.RBUplata);
            this.groupBox1.Location = new System.Drawing.Point(239, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(186, 151);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Operacije";
            // 
            // RBTransfer
            // 
            this.RBTransfer.AutoSize = true;
            this.RBTransfer.Location = new System.Drawing.Point(6, 118);
            this.RBTransfer.Name = "RBTransfer";
            this.RBTransfer.Size = new System.Drawing.Size(93, 24);
            this.RBTransfer.TabIndex = 4;
            this.RBTransfer.Text = "Transfer";
            this.RBTransfer.UseVisualStyleBackColor = true;
            this.RBTransfer.CheckedChanged += new System.EventHandler(this.RBIstorija_CheckedChanged);
            // 
            // RBUpit
            // 
            this.RBUpit.AutoSize = true;
            this.RBUpit.Location = new System.Drawing.Point(6, 87);
            this.RBUpit.Name = "RBUpit";
            this.RBUpit.Size = new System.Drawing.Size(110, 24);
            this.RBUpit.TabIndex = 3;
            this.RBUpit.Text = "Upit stanja";
            this.RBUpit.UseVisualStyleBackColor = true;
            this.RBUpit.CheckedChanged += new System.EventHandler(this.RBUpit_CheckedChanged);
            // 
            // RBIsplata
            // 
            this.RBIsplata.AutoSize = true;
            this.RBIsplata.Location = new System.Drawing.Point(7, 57);
            this.RBIsplata.Name = "RBIsplata";
            this.RBIsplata.Size = new System.Drawing.Size(82, 24);
            this.RBIsplata.TabIndex = 1;
            this.RBIsplata.Text = "Isplata";
            this.RBIsplata.UseVisualStyleBackColor = true;
            this.RBIsplata.CheckedChanged += new System.EventHandler(this.RBIsplata_CheckedChanged);
            // 
            // RBUplata
            // 
            this.RBUplata.AutoSize = true;
            this.RBUplata.Checked = true;
            this.RBUplata.Location = new System.Drawing.Point(7, 26);
            this.RBUplata.Name = "RBUplata";
            this.RBUplata.Size = new System.Drawing.Size(81, 24);
            this.RBUplata.TabIndex = 0;
            this.RBUplata.TabStop = true;
            this.RBUplata.Text = "Uplata";
            this.RBUplata.UseVisualStyleBackColor = true;
            this.RBUplata.CheckedChanged += new System.EventHandler(this.RBUplata_CheckedChanged);
            // 
            // TBRacun
            // 
            this.TBRacun.Location = new System.Drawing.Point(104, 12);
            this.TBRacun.Name = "TBRacun";
            this.TBRacun.Size = new System.Drawing.Size(129, 26);
            this.TBRacun.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Broj racuna";
            // 
            // LStrelica
            // 
            this.LStrelica.AutoSize = true;
            this.LStrelica.Location = new System.Drawing.Point(87, 41);
            this.LStrelica.Name = "LStrelica";
            this.LStrelica.Size = new System.Drawing.Size(20, 20);
            this.LStrelica.TabIndex = 4;
            this.LStrelica.Text = "V";
            // 
            // TBIznos
            // 
            this.TBIznos.Location = new System.Drawing.Point(104, 65);
            this.TBIznos.Name = "TBIznos";
            this.TBIznos.Size = new System.Drawing.Size(129, 26);
            this.TBIznos.TabIndex = 5;
            // 
            // TBRacunUplate
            // 
            this.TBRacunUplate.Location = new System.Drawing.Point(104, 99);
            this.TBRacunUplate.Name = "TBRacunUplate";
            this.TBRacunUplate.Size = new System.Drawing.Size(129, 26);
            this.TBRacunUplate.TabIndex = 6;
            this.TBRacunUplate.Visible = false;
            // 
            // LIznos
            // 
            this.LIznos.AutoSize = true;
            this.LIznos.Location = new System.Drawing.Point(50, 68);
            this.LIznos.Name = "LIznos";
            this.LIznos.Size = new System.Drawing.Size(48, 20);
            this.LIznos.TabIndex = 7;
            this.LIznos.Text = "Iznos";
            // 
            // LRacun
            // 
            this.LRacun.AutoSize = true;
            this.LRacun.Location = new System.Drawing.Point(42, 102);
            this.LRacun.Name = "LRacun";
            this.LRacun.Size = new System.Drawing.Size(56, 20);
            this.LRacun.TabIndex = 8;
            this.LRacun.Text = "Racun";
            this.LRacun.Visible = false;
            // 
            // BTNIzvrsi
            // 
            this.BTNIzvrsi.Location = new System.Drawing.Point(15, 131);
            this.BTNIzvrsi.Name = "BTNIzvrsi";
            this.BTNIzvrsi.Size = new System.Drawing.Size(92, 41);
            this.BTNIzvrsi.TabIndex = 9;
            this.BTNIzvrsi.Text = "Izvrsi";
            this.BTNIzvrsi.UseVisualStyleBackColor = true;
            this.BTNIzvrsi.Click += new System.EventHandler(this.BTNIzvrsi_Click);
            // 
            // BTNOcisti
            // 
            this.BTNOcisti.Location = new System.Drawing.Point(113, 131);
            this.BTNOcisti.Name = "BTNOcisti";
            this.BTNOcisti.Size = new System.Drawing.Size(92, 41);
            this.BTNOcisti.TabIndex = 10;
            this.BTNOcisti.Text = "Ocisti";
            this.BTNOcisti.UseVisualStyleBackColor = true;
            this.BTNOcisti.Click += new System.EventHandler(this.BTNOcisti_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 418);
            this.Controls.Add(this.BTNOcisti);
            this.Controls.Add(this.BTNIzvrsi);
            this.Controls.Add(this.LRacun);
            this.Controls.Add(this.LIznos);
            this.Controls.Add(this.TBRacunUplate);
            this.Controls.Add(this.TBIznos);
            this.Controls.Add(this.LStrelica);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TBRacun);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.RTBlog);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox RTBlog;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton RBTransfer;
        private System.Windows.Forms.RadioButton RBUpit;
        private System.Windows.Forms.RadioButton RBIsplata;
        private System.Windows.Forms.RadioButton RBUplata;
        private System.Windows.Forms.TextBox TBRacun;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LStrelica;
        private System.Windows.Forms.TextBox TBIznos;
        private System.Windows.Forms.TextBox TBRacunUplate;
        private System.Windows.Forms.Label LIznos;
        private System.Windows.Forms.Label LRacun;
        private System.Windows.Forms.Button BTNIzvrsi;
        private System.Windows.Forms.Button BTNOcisti;
    }
}

